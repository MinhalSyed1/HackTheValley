angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('menu.home', {
    url: '/page1',
    views: {
      'side-menu21': {
        templateUrl: 'templates/home.html',
        controller: 'homeCtrl'
      }
    }
  })

  .state('menu', {
    url: '/side-menu21',
    templateUrl: 'templates/menu.html',
    controller: 'menuCtrl'
  })

  .state('menu.report', {
    url: '/page4',
    views: {
      'side-menu21': {
        templateUrl: 'templates/report.html',
        controller: 'reportCtrl'
      }
    }
  })

  .state('menu.success', {
    url: '/page5',
    views: {
      'side-menu21': {
        templateUrl: 'templates/success.html',
        controller: 'successCtrl'
      }
    }
  })

  .state('menu.points', {
    url: '/page6',
    views: {
      'side-menu21': {
        templateUrl: 'templates/points.html',
        controller: 'pointsCtrl'
      }
    }
  })

  .state('leadership', {
    url: '/page7',
    templateUrl: 'templates/leadership.html',
    controller: 'leadershipCtrl'
  })

$urlRouterProvider.otherwise('/side-menu21/page1')

  

});